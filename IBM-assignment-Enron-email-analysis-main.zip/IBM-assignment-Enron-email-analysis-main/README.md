# IBM-assignment-Enron-email-analysis
How to ope  file 

Open in google colab.

Contents:

Business Report (Code, Analysis)

Development Notebook (Pseudocode, Testing, Industry Standards)

Non Conformance Report

Readme

This assignemnt analyses the data of Enron database.This repository contain files previously mentioned.
